using System.Collections.Generic;

using System.Net.Http;
using System.Security;

using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace AsPartitionProcessing.SampleAzureFunction
{
    public static class ASFunction
    {

        private static string _modelConfigurationIDs;
        [FunctionName("ASPartition")]
        public static async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)]HttpRequestMessage req, TraceWriter log)
        {
            log.Info($"C# Timer trigger function (fAsPartitionProcessingTimer) started at: {DateTime.Now}");
            String azure_AppID = "";
            try
            {
                /* read from ASPP_ConfigurationLoggingDB */
                List<ModelConfiguration> modelsConfig = InitializeFromDatabase();

                /* loop through Model Config */
                foreach (ModelConfiguration modelConfig in modelsConfig)
                {
                    /* grab user/pw for AzureAS authentication */

                    azure_AppID = "96c5b4da-8640-469a-8e00-b58cbc06fa26";//System.Environment.GetEnvironmentVariable("AzureAS_SvcPrincipal_AppID");
                    String azure_AppKey = "Pc8xB6_ONDdES7-D5ir2iMV9guk.7ohW~j";//System.Environment.GetEnvironmentVariable("AzureAS_SvcPrincipal_AppKey");

                    /* apparently you can do it this way as well */
                    modelConfig.UserName = azure_AppID;
                    modelConfig.Password = azure_AppKey;

                    /* perform processing */
                    PartitionProcessor.PerformProcessing(modelConfig, ConfigDatabaseHelper.LogMessage);
                }
            }
            catch (Exception e)
            {
                log.Info($"C# Timer trigger function (fAsPartitionProcessingTimer) exception: {e.ToString()}");
            }

            log.Info($"C# Timer trigger function (fAsPartitionProcessingTimer) finished at: {DateTime.Now}");

            log.Info("This is azure id" + azure_AppID);

            return new OkObjectResult("code executed successfully "+ azure_AppID);
        }


        public static List<ModelConfiguration> InitializeFromDatabase()
        {
            ConfigDatabaseConnectionInfo connectionInfo = new ConfigDatabaseConnectionInfo();

            connectionInfo.Server = "dbepaztst03.database.windows.net"; //dbepaztst03.database.windows.net//System.Environment.GetEnvironmentVariable("ConfigurationLogging_SERVER");
            connectionInfo.Database = "CDPAuditLogsdev";//DRDWHDEV //System.Environment.GetEnvironmentVariable("ConfigurationLogging_DB");
            connectionInfo.UserName = "ODS_SA";// INFA_SA//System.Environment.GetEnvironmentVariable("ConfigurationLogging_USER");
            connectionInfo.Password = "uit9a9qxwAPDdmY6WXpQ";//TsTCandriam7508Informatica759SA //System.Environment.GetEnvironmentVariable("ConfigurationLogging_PW");

            return ConfigDatabaseHelper.ReadConfig(connectionInfo, _modelConfigurationIDs);
        }
    }
}
